#**frogger**

#**Frontend-Nanodegree-Arcade-Game**
===============================

##**How to run the game**

Download the frogger game from the URL given below and save the files in a folder on your computer. Open index.html in Chrome to start playing the game.

https://github.com/SumaiyaA/frogger

##**How to play the game**

In this game you have a Player and Enemies (Bugs). The goal of the player is to reach the water, without colliding into any one of the enemies. The player can move left, right, up and down. Once the player collides with an enemy, the game is reset and the player moves back to the start square. Once the player reaches the water the game is won.
